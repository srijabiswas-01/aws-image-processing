import json
import os
import urllib.parse
import boto3
from PIL import Image

s3 = boto3.client("s3")
sns = boto3.client("sns")

SNS_TOPIC_ARN = "arn:aws:sns:us-east-1:409326484181:srija-image-processing-notifications"

def lambda_handler(event, context):

    for record in event.get("Records", []):

        body = json.loads(record["body"])

        # Ignore S3 test events
        if body.get("Event") == "s3:TestEvent":
            print("Ignoring S3 test event")
            continue

        for s3_record in body.get("Records", []):

            bucket = s3_record["s3"]["bucket"]["name"]

            key = urllib.parse.unquote_plus(
                s3_record["s3"]["object"]["key"]
            )

            print(f"Processing: s3://{bucket}/{key}")

            if not key.startswith("uploads/"):
                print("Skipping non-upload object")
                continue

            filename = os.path.basename(key)

            input_path = f"/tmp/{filename}"
            output_path = f"/tmp/processed-{filename}"

            # Download original image
            s3.download_file(bucket, key, input_path)

            original_size = os.path.getsize(input_path)

            # Resize image
            with Image.open(input_path) as image:

                original_width, original_height = image.size

                image.thumbnail((800, 800))

                processed_width, processed_height = image.size

                # Save consistently as JPEG
                if image.mode not in ("RGB", "L"):
                    image = image.convert("RGB")

                image.save(
                    output_path,
                    format="JPEG",
                    quality=85,
                    optimize=True
                )

            processed_size = os.path.getsize(output_path)

            processed_key = f"processed/{filename}"

            # Upload processed image
            s3.upload_file(
                output_path,
                bucket,
                processed_key,
                ExtraArgs={
                    "ContentType": "image/jpeg"
                }
            )

            reduction = 0

            if original_size > 0:
                reduction = round(
                    (
                        (original_size - processed_size)
                        / original_size
                    ) * 100,
                    2
                )

            message = f"""
Image Processing Completed Successfully

Filename: {filename}

Original Image
Dimensions: {original_width} x {original_height}
Size: {round(original_size / 1024, 2)} KB
Location: s3://{bucket}/{key}

Processed Image
Dimensions: {processed_width} x {processed_height}
Size: {round(processed_size / 1024, 2)} KB
Location: s3://{bucket}/{processed_key}

File Size Reduction: {reduction}%
"""

            sns.publish(
                TopicArn=SNS_TOPIC_ARN,
                Subject="Srija Image Processing Completed",
                Message=message
            )

            print(f"Processed image saved to: {processed_key}")

    return {
        "statusCode": 200,
        "body": "Image processing completed"
    }